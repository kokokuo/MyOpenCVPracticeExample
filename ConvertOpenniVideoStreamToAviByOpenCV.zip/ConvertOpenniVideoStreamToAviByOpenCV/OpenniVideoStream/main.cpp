#include <stdio.h>
#include <iostream>
#include <OpenNI.h>
#include <opencv2\core\core.hpp>
#include <opencv2\imgproc\imgproc.hpp>
#include <opencv2\highgui\highgui.hpp>
using namespace std;

//openni
//reference : http://kheresy.wordpress.com/2013/01/09/%E7%94%A8-opencv-%E7%95%AB%E5%87%BA-openni-2-%E7%9A%84%E6%B7%B1%E5%BA%A6%E3%80%81%E5%BD%A9%E8%89%B2%E5%BD%B1%E5%83%8F/
//reference : http://kheresy.wordpress.com/2013/03/04/record-and-playback-of-openni-2/

//opencv : http://blog.csdn.net/yang_xian521/article/details/7440190
int main(){

	// initialize OpenNI
	openni::OpenNI::initialize();
   
	// open a device
	openni::Device devAnyDevice;
	//devAnyDevice.open( openni::ANY_DEVICE );
   
	//open oni video
	devAnyDevice.open( "..\\q8.oni" );  // this string is your oni file url 
	
	openni::VideoStream streamColor;
	if(devAnyDevice.hasSensor(openni::SENSOR_COLOR)){
		// create depth stream
		if(streamColor.create( devAnyDevice, openni::SENSOR_COLOR ) == openni::STATUS_OK ){
			
			streamColor.start();
		}
		else{
			cerr << "ERROR: This device does not have color sensor" << endl;
			system("pause");
			return -1;
		}
		
	}
	

	//Get Frame number by playbackController
    openni::PlaybackControl* pController = devAnyDevice.getPlaybackControl();
	int total = pController->getNumberOfFrames(streamColor);

	 cv::namedWindow( "Color Image",  CV_WINDOW_AUTOSIZE );
	
	 // 5 main loop, continue read
	openni::VideoFrameRef frameColor;
	
	cv::VideoWriter writer("..\\VideoTest.avi", CV_FOURCC('M', 'J', 'P', 'G'), 25.0, cv::Size(640, 480));  
	for( int i = 0; i < total; ++ i )
	{
		// check is color stream is available
		if( streamColor.isValid() )
		{
			//  get color frame
			if( streamColor.readFrame( &frameColor ) == openni::STATUS_OK )
			{
				//  convert data to OpenCV format
				const cv::Mat mImageRGB(
						frameColor.getHeight(), frameColor.getWidth(),
						CV_8UC3, (void*)frameColor.getData() );
			
				//  convert form RGB to BGR
				cv::Mat cImageBGR;
				cv::cvtColor( mImageRGB, cImageBGR, CV_RGB2BGR );
				cout << cImageBGR.cols << "," << cImageBGR.rows <<endl;

				cv::resize(cImageBGR,cImageBGR,cv::Size(640,480),cv::INTER_LINEAR);

				//will error because of libiconv-2.dll ,this is a x86 version bug for opencv,this bug fixed in opencv 2.4.8
				//http://code.opencv.org/issues/3400
				writer << cImageBGR; 
				 
				//  show image
				cv::imshow( "Color Image", cImageBGR );
			}
		}

		//  check keyboard
		if( cv::waitKey( 1 ) == 'q' )
		  break;
	}
   
	// close
	streamColor.destroy();
	devAnyDevice.close();
   
	// shutdown
	openni::OpenNI::shutdown();
	system("pause");
	return 0;
}