This is a sample for converting openni file oni to avi by using opencv

API & SDK
Openni2 : OpenNI-Windows-x86-2.2.0.33
opencv 2.4.7

and this project has added libiconv-2.dll (this's need by opencv 2.4.7,but fixed in opencv 2.4.8)

reference by
1. http://kheresy.wordpress.com/index_of_openni_and_kinect/
2. http://blog.csdn.net/yang_xian521/article/details/7440190

write the code yi.cheng.kuo 2014/3/22